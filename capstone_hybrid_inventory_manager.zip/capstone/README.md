# Capstone – Hybrid Inventory Manager

A console-based inventory manager where the **data layer is written in C** (binary file I/O with `fread`/`fwrite`/`fseek`) and the **UI/logic layer is written in C++** (classes, `std::vector`, `std::sort`).  Data persists across restarts in `inventory.dat`.

---

## File Structure

```
capstone/
├── include/
│   ├── inventory.h          # C struct + extern "C" API declaration
│   └── InventoryManager.h   # C++ class declaration
├── src/
│   ├── inventory.c          # C backend (binary file storage)
│   ├── InventoryManager.cpp # C++ wrapper + STL usage
│   └── main.cpp             # Entry point + menu
├── Makefile
├── CMakeLists.txt
└── README.md
```

---

## Build & Run

### Option A – Make (recommended)

```bash
cd capstone
make          # builds ./inventory_mgr
./inventory_mgr
```

To clean build artifacts and the data file:

```bash
make clean
```

### Option B – CMake

```bash
cd capstone
mkdir -p build && cd build
cmake ..
make
./inventory_mgr
```

> **Requirements:** GCC/G++ 9+ (or Clang equivalent) with C11 and C++17 support.

---

## How It Works

| Layer | Language | Responsibility |
|-------|----------|----------------|
| `inventory.c` | C | Binary file CRUD – `fread`, `fwrite`, `fseek` |
| `InventoryManager.cpp` | C++ | Menu actions, validated input, STL sorting |
| `main.cpp` | C++ | Menu loop, dispatch |

Items are stored at fixed offsets: record with ID `n` lives at byte offset `(n-1) × sizeof(Item)`, so every seek is O(1).  Deletion sets `is_deleted = 1`; the record stays on disk but is invisible to all list/view operations.

---

## Menu Options

```
1. Add item
2. View item
3. Update item
4. Delete item
5. List all
6. Exit
```

---

## Input Validation

| Field    | Rule |
|----------|------|
| ID       | Must be a positive integer; duplicate active IDs are rejected |
| Name     | Must not be empty; must be < 40 characters |
| Quantity | Must be ≥ 0 |
| Price    | Must be ≥ 0.00 |

On invalid input the program prints an error and re-prompts — it never crashes.

---

## Test Cases

- **TC-1 – Persistence:** Added items 1 (`Apple`, qty=10, price=0.99), 2 (`Banana`, qty=5, price=0.50), and 3 (`Cherry`, qty=100, price=2.49) then exited.  Re-ran the program and selected *List all* — all three items appeared correctly.

- **TC-2 – Duplicate ID rejected:** Tried to add a second item with ID=1.  The program printed `Failed – ID 1 may already exist` and did not overwrite the original record.

- **TC-3 – Update persists:** Updated item 2 (changed name to `Blueberry`, qty=20, price=1.25) then exited.  After restarting, *View item 2* showed the updated values, not the originals.

- **TC-4 – Soft delete:** Deleted item 3 then chose *List all* — only items 1 and 2 appeared.  Choosing *View item 3* returned `not found or has been deleted`.  After restart, item 3 remained invisible.

- **TC-5 – Invalid input recovery:** Entered `-5` for ID, `abc` for quantity, and left the name blank.  The program re-prompted each time without crashing, and accepted the corrected values on the next attempt.

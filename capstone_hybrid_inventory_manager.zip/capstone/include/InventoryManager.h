#ifndef INVENTORY_MANAGER_H
#define INVENTORY_MANAGER_H

#include <string>
#include <vector>
#include "inventory.h"

class InventoryManager {
public:
    InventoryManager();

    void add();      /* Add a new item      */
    void view();     /* View one item by ID */
    void update();   /* Update an item      */
    void remove();   /* Soft-delete an item */
    void list();     /* List all items      */

private:
    /* Validated input helpers */
    int         prompt_id      (const std::string &prompt) const;
    int         prompt_quantity(const std::string &prompt) const;
    float       prompt_price   (const std::string &prompt) const;
    std::string prompt_name    (const std::string &prompt) const;
};

#endif /* INVENTORY_MANAGER_H */

/*
 * main.cpp  –  entry point
 * Displays the menu and dispatches to InventoryManager methods.
 */

#include <iostream>
#include <limits>
#include "InventoryManager.h"

static void print_menu()
{
    std::cout
        << "\n╔══════════════════════════════╗\n"
        << "║   Hybrid Inventory Manager   ║\n"
        << "╠══════════════════════════════╣\n"
        << "║  1. Add item                 ║\n"
        << "║  2. View item                ║\n"
        << "║  3. Update item              ║\n"
        << "║  4. Delete item              ║\n"
        << "║  5. List all                 ║\n"
        << "║  6. Exit                     ║\n"
        << "╚══════════════════════════════╝\n"
        << "  Choice: ";
}

int main()
{
    InventoryManager mgr;
    int choice;

    while (true) {
        print_menu();

        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "  [!] Please enter a number 1-6.\n";
            continue;
        }
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        switch (choice) {
            case 1: mgr.add();    break;
            case 2: mgr.view();   break;
            case 3: mgr.update(); break;
            case 4: mgr.remove(); break;
            case 5: mgr.list();   break;
            case 6:
                std::cout << "  Goodbye.\n";
                return 0;
            default:
                std::cout << "  [!] Invalid option. Choose 1-6.\n";
        }
    }
}

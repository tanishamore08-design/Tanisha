/*
 * InventoryManager.cpp  –  C++ UI / logic layer
 *
 * Wraps the C backend.  Uses:
 *   std::vector   – to hold items temporarily while listing
 *   std::sort     – to sort items before printing
 */

#include "InventoryManager.h"
#include "inventory.h"

#include <algorithm>
#include <iomanip>
#include <iostream>
#include <cstring>
#include <limits>
#include <sstream>

/* ------------------------------------------------------------------ helpers */

static void flush_cin()
{
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

/* Print a single item row inside the table */
static void print_row(const Item &it)
{
    std::cout
        << "| " << std::setw(5)  << std::left  << it.id
        << "| " << std::setw(20) << std::left  << it.name
        << "| " << std::setw(8)  << std::right << it.quantity
        << " | " << std::setw(9) << std::fixed << std::setprecision(2) << it.price
        << " |\n";
}

static void print_table_header()
{
    std::cout
        << "+------+---------------------+---------+-----------+\n"
        << "| ID   | Name                | Qty     | Price     |\n"
        << "+------+---------------------+---------+-----------+\n";
}

static void print_table_footer()
{
    std::cout << "+------+---------------------+---------+-----------+\n";
}

/* ------------------------------------------------------------------ InventoryManager */

InventoryManager::InventoryManager() {}

/* ---------- validated input helpers ---------- */

int InventoryManager::prompt_id(const std::string &prompt) const
{
    int v;
    while (true) {
        std::cout << prompt;
        if (std::cin >> v && v > 0) { flush_cin(); return v; }
        std::cout << "  [!] ID must be a positive integer. Try again.\n";
        flush_cin();
    }
}

int InventoryManager::prompt_quantity(const std::string &prompt) const
{
    int v;
    while (true) {
        std::cout << prompt;
        if (std::cin >> v && v >= 0) { flush_cin(); return v; }
        std::cout << "  [!] Quantity must be 0 or more. Try again.\n";
        flush_cin();
    }
}

float InventoryManager::prompt_price(const std::string &prompt) const
{
    float v;
    while (true) {
        std::cout << prompt;
        if (std::cin >> v && v >= 0.0f) { flush_cin(); return v; }
        std::cout << "  [!] Price must be 0.00 or more. Try again.\n";
        flush_cin();
    }
}

std::string InventoryManager::prompt_name(const std::string &prompt) const
{
    std::string s;
    while (true) {
        std::cout << prompt;
        std::getline(std::cin, s);
        if (!s.empty() && s.length() < NAME_LEN) return s;
        if (s.empty())
            std::cout << "  [!] Name must not be empty. Try again.\n";
        else
            std::cout << "  [!] Name must be fewer than " << NAME_LEN << " characters. Try again.\n";
    }
}

/* ---------- menu actions ---------- */

void InventoryManager::add()
{
    std::cout << "\n── Add Item ──────────────────────────────\n";
    Item it{};
    it.id         = prompt_id      ("  ID       : ");
    std::string n = prompt_name    ("  Name     : ");
    it.quantity   = prompt_quantity("  Quantity : ");
    it.price      = prompt_price   ("  Price    : ");
    it.is_deleted = 0;

    /* Copy name safely */
    strncpy(it.name, n.c_str(), NAME_LEN - 1);
    it.name[NAME_LEN - 1] = '\0';

    if (add_item(&it))
        std::cout << "  [✓] Item " << it.id << " added.\n";
    else
        std::cout << "  [✗] Failed – ID " << it.id << " may already exist.\n";
}

void InventoryManager::view()
{
    std::cout << "\n── View Item ─────────────────────────────\n";
    int id = prompt_id("  ID : ");
    Item it{};
    if (get_item(id, &it)) {
        print_table_header();
        print_row(it);
        print_table_footer();
    } else {
        std::cout << "  [✗] Item " << id << " not found or has been deleted.\n";
    }
}

void InventoryManager::update()
{
    std::cout << "\n── Update Item ───────────────────────────\n";
    int id = prompt_id("  ID to update : ");

    Item existing{};
    if (!get_item(id, &existing)) {
        std::cout << "  [✗] Item " << id << " not found or has been deleted.\n";
        return;
    }

    std::cout << "  Current: " << existing.name
              << "  Qty=" << existing.quantity
              << "  Price=" << existing.price << "\n"
              << "  (Enter new values)\n";

    Item updated{};
    updated.id        = id;
    std::string n     = prompt_name    ("  New name     : ");
    updated.quantity  = prompt_quantity("  New quantity : ");
    updated.price     = prompt_price   ("  New price    : ");
    updated.is_deleted = 0;

    strncpy(updated.name, n.c_str(), NAME_LEN - 1);
    updated.name[NAME_LEN - 1] = '\0';

    if (update_item(id, &updated))
        std::cout << "  [✓] Item " << id << " updated.\n";
    else
        std::cout << "  [✗] Update failed.\n";
}

void InventoryManager::remove()
{
    std::cout << "\n── Delete Item ───────────────────────────\n";
    int id = prompt_id("  ID to delete : ");
    if (delete_item(id))
        std::cout << "  [✓] Item " << id << " deleted (soft).\n";
    else
        std::cout << "  [✗] Item " << id << " not found or already deleted.\n";
}

void InventoryManager::list()
{
    std::cout << "\n── List All Items ────────────────────────\n";

    const int MAX = 1024;
    Item buf[MAX];
    int  n = list_items(buf, MAX);

    if (n == 0) {
        std::cout << "  (no active items)\n";
        return;
    }

    /* STL: copy into vector, sort by id */
    std::vector<Item> items(buf, buf + n);
    std::sort(items.begin(), items.end(),
              [](const Item &a, const Item &b){ return a.id < b.id; });

    print_table_header();
    for (const auto &it : items) print_row(it);
    print_table_footer();
    std::cout << "  " << n << " item(s) found.\n";
}

/*
 * inventory.c  –  C data layer
 * Binary file storage using fread / fwrite / fseek.
 * Each record occupies exactly sizeof(Item) bytes at offset (id-based index).
 * We store records at position (id - 1) * sizeof(Item) so seeking is O(1).
 *
 * Rules:
 *   - IDs are 1-based positive integers chosen by the caller.
 *   - add_item rejects a duplicate (non-deleted) id.
 *   - delete_item sets is_deleted = 1 (soft delete).
 *   - list_items skips records where is_deleted == 1.
 */

#include <stdio.h>
#include <string.h>
#include "inventory.h"

/* ------------------------------------------------------------------ helpers */

/* Return a FILE* positioned at the start of record <id>.
 * mode should be "r+b" (read-write) or "rb" (read-only).
 * Caller must fclose the returned pointer.
 * Returns NULL if the file cannot be opened or id is out of range. */
static FILE *open_at(int id, const char *mode)
{
    if (id <= 0) return NULL;

    FILE *fp = fopen(DB_FILE, mode);
    if (!fp) {
        /* For read-write mode, try creating a fresh file first */
        if (mode[0] == 'r' && mode[1] == '+') {
            fp = fopen(DB_FILE, "w+b");
        }
        if (!fp) return NULL;
    }

    long offset = (long)(id - 1) * (long)sizeof(Item);
    if (fseek(fp, offset, SEEK_SET) != 0) {
        fclose(fp);
        return NULL;
    }
    return fp;
}

/* Read the record at position id into *out.
 * Returns 1 on success, 0 on failure (no such record or I/O error). */
static int read_record(int id, Item *out)
{
    FILE *fp = open_at(id, "rb");
    if (!fp) return 0;

    int ok = (fread(out, sizeof(Item), 1, fp) == 1);
    fclose(fp);
    return ok;
}

/* ------------------------------------------------------------------ public API */

int add_item(const Item *item)
{
    if (!item || item->id <= 0) return 0;

    /* Reject duplicate active id */
    Item existing;
    if (read_record(item->id, &existing) && !existing.is_deleted)
        return 0;   /* id already in use */

    FILE *fp = open_at(item->id, "r+b");
    if (!fp) {
        /* File might not exist yet – create it */
        fp = fopen(DB_FILE, "a+b");
        if (!fp) return 0;
        /* Now seek to the correct offset */
        long offset = (long)(item->id - 1) * (long)sizeof(Item);
        if (fseek(fp, offset, SEEK_SET) != 0) { fclose(fp); return 0; }
    }

    int ok = (fwrite(item, sizeof(Item), 1, fp) == 1);
    fflush(fp);
    fclose(fp);
    return ok;
}

int get_item(int id, Item *out)
{
    if (!out || id <= 0) return 0;

    if (!read_record(id, out)) return 0;
    if (out->is_deleted)       return 0;   /* treat soft-deleted as missing */
    return 1;
}

int update_item(int id, const Item *updated)
{
    if (!updated || id <= 0) return 0;

    /* Verify the record exists and is active */
    Item existing;
    if (!read_record(id, &existing) || existing.is_deleted) return 0;

    FILE *fp = open_at(id, "r+b");
    if (!fp) return 0;

    /* Write the updated record; preserve the original id */
    Item to_write = *updated;
    to_write.id   = id;
    to_write.is_deleted = 0;

    int ok = (fwrite(&to_write, sizeof(Item), 1, fp) == 1);
    fflush(fp);
    fclose(fp);
    return ok;
}

int delete_item(int id)
{
    if (id <= 0) return 0;

    Item existing;
    if (!read_record(id, &existing) || existing.is_deleted) return 0;

    existing.is_deleted = 1;

    FILE *fp = open_at(id, "r+b");
    if (!fp) return 0;

    int ok = (fwrite(&existing, sizeof(Item), 1, fp) == 1);
    fflush(fp);
    fclose(fp);
    return ok;
}

int list_items(Item *buffer, int max_items)
{
    if (!buffer || max_items <= 0) return 0;

    FILE *fp = fopen(DB_FILE, "rb");
    if (!fp) return 0;

    int count = 0;
    Item tmp;

    while (count < max_items && fread(&tmp, sizeof(Item), 1, fp) == 1) {
        if (!tmp.is_deleted) {
            buffer[count++] = tmp;
        }
    }

    fclose(fp);
    return count;
}
